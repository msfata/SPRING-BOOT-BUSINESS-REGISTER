package com.rest.jpa.simple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailProjectApplication.class, args);
	}
}
