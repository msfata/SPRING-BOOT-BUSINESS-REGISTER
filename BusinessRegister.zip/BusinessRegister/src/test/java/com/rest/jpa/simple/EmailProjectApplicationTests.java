package com.rest.jpa.simple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
